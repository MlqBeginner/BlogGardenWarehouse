package com.gdbd.realms;

import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;

import java.util.HashSet;
import java.util.Set;

/**
 * 第一道 加密的方式 MD5
 * @author asus
 * 1）：单一实现认证：AuthenticatingRealm
 * 2）：授权+认证 ：AuthorizingRealm
 */
public class ShiroRealm extends AuthorizingRealm {

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token)
            throws AuthenticationException {

        System.out.println("[SecondRealm--one]==doGetAuthenticationInfo");
        System.out.println("doGetAuthenticationInfo" + token);
        System.out.println("2.token.hashCode()" + token.hashCode());

        //1、把AuthenticationToken 转换为 UsernamePasswordToken
        UsernamePasswordToken upToken = (UsernamePasswordToken) token;
        //2、从 UsernamePasswordToken 中获取 username
        String username = upToken.getUsername();
        String password =new String( upToken.getPassword());
        System.out.println("======username:=======" + username + "======username:=======" + password);
        //3、使用数据库方法，从数据库中查询 username 对应的用户记录
        System.out.println("从数据库中获取 username：" + username + "所对应的用户信息");
        //4、若用户不存在，则可以抛出 UnknownAccountException 异常
        if ("unknown".equals(username)) {
            throw new UnknownAccountException("用户不存在");
        }
        //5、根据用户信息的情况，决定是否需要抛出其他的 AuthenticationException 异常
        if ("monster".equals(username)) {
            throw new LockedAccountException("用户被锁定！！！");
        }
        //6、根据用户的情况 来构建 AuthenticationInfo 对象并返回
        /***
         * 通常使用的实现类为：SimpleAuthenticationInfo
         * 1）:principal：认证的实体信息，可以是 username，
         *    也可以是数据表对应的用户的实体类对象。
         * 2）：credentials：密码
         * 3）：realmName：当前 realm 对象的name  调用父类的getName() 方法即可
         */
        Object principal =username;
        //数据库查询出来的密码  123456--加密1024次：fc1709d0a95a6be30bc5926fdb7f22f4
        //简单模拟不同用户登陆
        Object credentials = "";
        if ("admin".equals(username)) {
            credentials = "038bdaf98f2037b31f1e75b5b4c9b26e";
        } else {
            credentials = "098d2c478e9c11555ce2823231e02ec1";
        }
        String realmName = this.getName();
        System.out.println("============"+realmName+"===============");
        SimpleAuthenticationInfo info = null;
        // info = new SimpleAuthenticationInfo(principal, credentials, realmName);
        // 使用盐值加密：防止两个人的密码一样导致加密后的密钥也一致性，所以要加点盐
        ByteSource credentialsSalt = ByteSource.Util.bytes(username);
        info = new SimpleAuthenticationInfo(principal, credentials, credentialsSalt, realmName);
        return info;
    }

    /**
     * 内部实现加密模拟测试
     * @param args
     */
    public static void main(String[] args) {
        String hashAlgorithmName = "MD5";
        Object credentials = "123456";
        Object salt = ByteSource.Util.bytes("user");
        int hashIterations = 1024;
        Object result = new SimpleHash(hashAlgorithmName, credentials, salt, hashIterations);
        System.out.println(result);
    }

    /***
     * 用于授权的方法
     * @param principalCollection
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        System.out.println("[doGetAuthorizationInfo:==进入授权管理]");
        //1、从PrincipalCollection 中来获取登录用户的信息
        Object primaryPrincipal = principalCollection.getPrimaryPrincipal();
        System.out.println("授权管理方法：当前登录名为："+primaryPrincipal);
        //2、利用登陆的用户的信息用来获取当前用户的角色或权限（可能需要查询数据库）
        /***
         * 无论是哪一个用户，默认都有查看 user 的权限，
         * 如果是admin用户登录，在追加user权限
         */
        Set<String> set = new HashSet<String>();
        set.add("user");
        if ("admin".equals(primaryPrincipal)) {
            set.add("admin");
        }
        //3、创建 SimpleAuthorizationInfo ，并设置其 reles 属性
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo(set);
        //4、返回 SimpleAuthenticationInfo 对象。
        return info;
    }
}
