package com.gdbd.controller;

import com.gdbd.service.ShiroService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

/**
 * @author asus
 */
@Controller
@RequestMapping("/shiro")
public class ShiroController {

    @Autowired
    private ShiroService shiroService;

    /***
     * 测试存在 Session中的值  是否可以在service中获取到
     * @param session
     * @return
     */
    @RequestMapping("/testAnnotation")
    public String testAnnotation(HttpSession session) {
        session.setAttribute("key", "HttpServletSession：存入的值");
        shiroService.show();
        return "redirect:/list.jsp";
    }


    /***
     * 登陆代码
     * @param userName
     * @param passWord
     * @return
     */
    @RequestMapping("/login")
    public String login(@RequestParam("userName") String userName,
                        @RequestParam("passWord") String passWord) {

        Subject currentUser = SecurityUtils.getSubject();
        if (!currentUser.isAuthenticated()) {
            // 把用户名和密码封装为 UsernamePasswordToken 对象
            UsernamePasswordToken token = new UsernamePasswordToken(userName, passWord);
            System.out.println("1.token.hashCode()" + token.hashCode());
            // rememberme 记住我
            token.setRememberMe(true);
            try {
                // 执行登录.
                System.out.println("-----执行登陆-----");
                currentUser.login(token);
            }
            // 所有认证时异常的父类.
            catch (AuthenticationException ae) {
                System.out.println("登陆失败" + ae.getMessage());
            }
        }
        return "redirect:/list.jsp";
    }

    /***
     * 登出清理缓存
     * @return
     */
    @RequestMapping("/exit")
    public String exit()
    {
        Subject currentUser = SecurityUtils.getSubject();
        currentUser.logout();
        return "login";
    }
}
