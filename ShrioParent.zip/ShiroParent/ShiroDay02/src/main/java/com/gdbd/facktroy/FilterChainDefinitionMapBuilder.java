package com.gdbd.facktroy;

import java.util.LinkedHashMap;

/**
 * 通过实例工厂方法的方式 实现是否有权限访问方法
 * @author asus
 */
public class FilterChainDefinitionMapBuilder {

    /***
     * 从数据库表中初始化资源和权限
     * @return
     */
    public LinkedHashMap<String, String> buildFilterChainDefinitionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();

        map.put("/login.jsp", "anon");
        map.put("/shiro/login", "anon");
        /***
         * 登出（缓存很严重【例如：成功登陆一次，再去登陆页面输入错误密码同样可以登录，
         * 不会再走相关 Realm 认证：所以需要先登出】）
         */
        map.put("/shiro/logout", "logout");
        //必须通过 登陆认证和具备匹配权限可以访问
        map.put("/user.jsp", "authc,roles[user]");
        map.put("/admin.jsp", "authc,roles[admin]");
        //通过记住我的功能，可以访问 list
        map.put("/list.jsp", "user");

        map.put("/**", "authc");

        return map;
    }
}
