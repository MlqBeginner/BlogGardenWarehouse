package com.gdbd.service;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.session.Session;

import java.util.Date;

/**
 * 注解实现是否有访问权限
 * @author asus
 */
public class ShiroService {

    /***
     * Shiro 注解方式实现是需要注意的是：
     * 在开发的过程中，往往会在 Seivice 中声明异 Transactional 处于事务管理就（即变成了一个代理对象）
     * 如果再写一个 Shiro 权限的注解会发生异常（类型转换错误）
     * ----------------------
     * 使用 SecurityUtils.getSubject().getSession() 可以获取到 HttpServletSession 中的值
     */

    @RequiresRoles({"admin"})
    public void show() {

        Session session = SecurityUtils.getSubject().getSession();
        System.out.println("使用 Shiro 中的Session 访问HttpServletSession的值为：" + session.getAttribute("key"));
        System.out.println("Shiro 权限注解测试方法：" + new Date());
    }


}
