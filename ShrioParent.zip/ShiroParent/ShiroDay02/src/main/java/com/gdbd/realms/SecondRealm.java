package com.gdbd.realms;

import org.apache.shiro.authc.*;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.realm.AuthenticatingRealm;
import org.apache.shiro.util.ByteSource;

/**
 * 第二道处理方式 SHA1 加密的方式  进行了双重密码认证
 * @author asus
 */
public class SecondRealm extends AuthenticatingRealm {

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token)
            throws AuthenticationException {
        System.out.println("[SecondRealm--Tow]==doGetAuthenticationInfo");
        System.out.println("doGetAuthenticationInfo" + token);
        System.out.println("2.token.hashCode()" + token.hashCode());

        //1、把AuthenticationToken 转换为 UsernamePasswordToken
        UsernamePasswordToken upToken = (UsernamePasswordToken) token;
        //2、从 UsernamePasswordToken 中获取 username
        String username = upToken.getUsername();
        String password = (upToken.getPassword()).toString();
        System.out.println("======username:=======" + username + "======username:=======" + password);
        //3、使用数据库方法，从数据库中查询 username 对应的用户记录
        System.out.println("从数据库中获取 username：" + username + "所对应的用户信息");
        //4、若用户不存在，则可以抛出 UnknownAccountException 异常
        if ("unknown".equals(username)) {
            throw new UnknownAccountException("用户不存在");
        }
        //5、根据用户信息的情况，决定是否需要抛出其他的 AuthenticationException 异常
        if ("monster".equals(username)) {
            throw new LockedAccountException("用户被锁定！！！");
        }
        //6、根据用户的情况 来构建 AuthenticationInfo 对象并返回
        /***
         * 通常使用的实现类为：SimpleAuthenticationInfo
         * 1）:principal：认证的实体信息，可以是 username，
         *    也可以是数据表对应的用户的实体类对象。
         * 2）：credentials：密码
         * 3）：realmName：当前 realm 对象的name  调用父类的getName() 方法即可
         */
        Object principal = username;
        //数据库查询出来的密码  123456--加密1024次：fc1709d0a95a6be30bc5926fdb7f22f4
        Object credentials = "";
        if ("admin".equals(username)) {
            credentials = "ce2f6417c7e1d32c1d81a797ee0b499f87c5de06";
        } else {
            credentials = "073d4c3ae812935f23cb3f2a71943f49e082a718";
        }
        String realmName = this.getName();
        SimpleAuthenticationInfo info = null;
        // info = new SimpleAuthenticationInfo(principal, credentials, realmName);
        // 使用盐值加密：防止两个人的密码一样导致加密后的密钥也一致性，所以要加点盐
        ByteSource credentialsSalt = ByteSource.Util.bytes(username);
        info = new SimpleAuthenticationInfo(principal, credentials, credentialsSalt, realmName);
        return info;
    }

    /***
     * 内部测试加密方式
     * @param args
     */
    public static void main(String[] args) {
        String hashAlgorithmName = "SHA1";
        Object credentials = "123456";
        Object salt = ByteSource.Util.bytes("admin");
        int hashIterations = 1024;
        Object result = new SimpleHash(hashAlgorithmName, credentials, salt, hashIterations);
        System.out.println(result);
    }
}
