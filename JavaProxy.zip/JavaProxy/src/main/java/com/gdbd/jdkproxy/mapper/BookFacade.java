package com.gdbd.jdkproxy.mapper;

/**
 * @author asus
 */
public interface BookFacade {

    /***
     * 添加图书
     */
    public void addBook();

}
