package com.gdbd.jdkproxy.mapper.impl;

import com.gdbd.jdkproxy.mapper.BookFacade;

/**
 * @author asus
 */
public class BookFacadeImpl implements BookFacade {

    @Override
    public void addBook() {
        System.out.println("增加图书方法。。。");
    }
}
