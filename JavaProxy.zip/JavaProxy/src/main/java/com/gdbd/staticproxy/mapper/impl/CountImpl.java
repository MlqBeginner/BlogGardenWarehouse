package com.gdbd.staticproxy.mapper.impl;

import com.gdbd.staticproxy.mapper.Count;

/**
 * @author asus
 */
public class CountImpl implements Count {

    @Override
    public void queryCount() {
        System.out.println("查看账户...");
    }

    @Override
    public void updateCount() {
        System.out.println("修改账户...");
    }
}
