package com.gdbd.staticproxy.mapper;

/**
 * @author asus
 */
public interface Count {

    /***
     * 查询账户
     */
    public void queryCount();

    /***
     * 修改账户
     */
    public void updateCount();

}
