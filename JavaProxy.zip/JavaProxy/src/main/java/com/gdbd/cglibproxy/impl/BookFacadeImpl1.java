package com.gdbd.cglibproxy.impl;

/**
 * @author asus
 */
public class BookFacadeImpl1 {

    public void addBook() {
        System.out.println("新增图书...");
    }

}
