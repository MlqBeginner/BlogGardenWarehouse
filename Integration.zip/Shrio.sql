/*
SQLyog v10.2 
MySQL - 5.5.44 : Database - shiro
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`shiro` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `shiro`;

/*Table structure for table `MenuInfo` */

DROP TABLE IF EXISTS `MenuInfo`;

CREATE TABLE `MenuInfo` (
  `mid` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键ID',
  `menuName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '菜单名称',
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='菜单表';

/*Data for the table `MenuInfo` */

insert  into `MenuInfo`(`mid`,`menuName`) values (1,'add'),(2,'del'),(3,'motiy'),(4,'sel');

/*Table structure for table `RoleInfo` */

DROP TABLE IF EXISTS `RoleInfo`;

CREATE TABLE `RoleInfo` (
  `rId` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色表ID',
  `RoleName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '角色名称',
  PRIMARY KEY (`rId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='角色表';

/*Data for the table `RoleInfo` */

insert  into `RoleInfo`(`rId`,`RoleName`) values (1,'超级管理员'),(2,'管理员'),(3,'普通用户');

/*Table structure for table `RoleMenu` */

DROP TABLE IF EXISTS `RoleMenu`;

CREATE TABLE `RoleMenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增ID',
  `RoleId` int(11) DEFAULT NULL COMMENT '角色ID',
  `MenuId` int(11) DEFAULT NULL COMMENT '菜单表ID',
  PRIMARY KEY (`id`),
  KEY `RoleMenu_RoleInfo_RoleId` (`RoleId`),
  KEY `RoleMenu_MenuInfo_MenuId` (`MenuId`),
  CONSTRAINT `RoleMenu_RoleInfo_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `RoleInfo` (`rId`),
  CONSTRAINT `RoleMenu_MenuInfo_MenuId` FOREIGN KEY (`MenuId`) REFERENCES `MenuInfo` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='角色菜单表';

/*Data for the table `RoleMenu` */

insert  into `RoleMenu`(`id`,`RoleId`,`MenuId`) values (1,1,1),(2,2,2),(3,3,3),(11,1,2),(12,1,3),(13,1,4);

/*Table structure for table `UserInfo` */

DROP TABLE IF EXISTS `UserInfo`;

CREATE TABLE `UserInfo` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键ID',
  `UserName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '用户名',
  `UserPwd` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '用户密码',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='用户表';

/*Data for the table `UserInfo` */

insert  into `UserInfo`(`Id`,`UserName`,`UserPwd`) values (1,'MLQ','123'),(2,'FKX','123'),(3,'WMJ','123');

/*Table structure for table `UserRole` */

DROP TABLE IF EXISTS `UserRole`;

CREATE TABLE `UserRole` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增ID',
  `userId` int(11) DEFAULT NULL COMMENT '用户ID',
  `roleId` int(11) DEFAULT NULL COMMENT '角色ID',
  PRIMARY KEY (`id`),
  KEY `UserRole_UserInfo_userId` (`userId`),
  KEY `UserRole_RoleInfo_rId` (`roleId`),
  CONSTRAINT `UserRole_RoleInfo_rId` FOREIGN KEY (`roleId`) REFERENCES `RoleInfo` (`rId`),
  CONSTRAINT `UserRole_UserInfo_userId` FOREIGN KEY (`userId`) REFERENCES `UserInfo` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='用户角色表';

/*Data for the table `UserRole` */

insert  into `UserRole`(`id`,`userId`,`roleId`) values (1,1,1),(2,2,2),(3,3,3);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
