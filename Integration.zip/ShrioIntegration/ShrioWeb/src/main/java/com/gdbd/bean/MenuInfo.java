package com.gdbd.bean;


/**
 * @author asus
 */
public class MenuInfo {

    private Integer mid;
    private String menuName;

    public Integer getMid() {
        return mid;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }
}
