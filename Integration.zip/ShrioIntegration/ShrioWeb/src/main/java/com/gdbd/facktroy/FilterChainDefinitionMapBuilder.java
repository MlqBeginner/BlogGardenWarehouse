package com.gdbd.facktroy;

import java.util.LinkedHashMap;

/**
 * @author asus
 */
public class FilterChainDefinitionMapBuilder {

    /***
     * 从数据库表中初始化资源和权限
     * @return
     */
    public LinkedHashMap<String, String> buildFilterChainDefinitionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();

        map.put("/login.jsp", "anon");
        map.put("/login", "anon");
        /***
         * 登出（缓存很严重【例如：成功登陆一次，再去登陆页面输入错误密码同样可以登录，
         * 不会再走相关 Realm 认证：所以需要先登出】）
         */
        map.put("/logout", "logout");
        map.put("/**", "authc");

        return map;
    }


}
