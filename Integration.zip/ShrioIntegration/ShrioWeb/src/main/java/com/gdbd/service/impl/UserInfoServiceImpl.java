package com.gdbd.service.impl;

import com.gdbd.bean.MenuInfo;
import com.gdbd.bean.RoleInfo;
import com.gdbd.bean.UserInfo;
import com.gdbd.mapper.UserInfoMapper;
import com.gdbd.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author asus
 */
@Service
public class UserInfoServiceImpl implements UserInfoService {

    @Autowired
    private UserInfoMapper userInfo;

    @Override
    public UserInfo userInfo(String name, String pwd) {
        return userInfo.userInfo(name, pwd);
    }

    @Override
    public List<RoleInfo> roleList() {
        return userInfo.roleList();
    }

    @Override
    public List<MenuInfo> menuList() {
        return userInfo.menuList();
    }

    @Override
    public String getPwd(String name) {
        return userInfo.getPwd(name);
    }

    @Override
    public List<String> getUserRoList(String name) {
        return userInfo.getUserRoList(name);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void addRo(Integer roleId,int[] menuId) {
        for (int item:menuId)
        {
            int i = userInfo.addRo(roleId, item);
            if (i==0)
            {
                throw new RuntimeException("权限绑定异常！！！");
            }
        }
    }
}
