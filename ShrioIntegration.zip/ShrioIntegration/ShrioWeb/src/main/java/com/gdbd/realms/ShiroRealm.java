package com.gdbd.realms;

import com.gdbd.service.UserInfoService;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author asus
 * 1）：单一实现认证：AuthenticatingRealm
 * 2）：授权+认证 ：AuthorizingRealm
 */
public class ShiroRealm extends AuthorizingRealm {

    @Autowired
    private UserInfoService userInfoService;

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token)
            throws AuthenticationException {

        //1、把AuthenticationToken 转换为 UsernamePasswordToken
        UsernamePasswordToken upToken = (UsernamePasswordToken) token;
        //当前用户名
        String principal = upToken.getUsername();
        //数据库查询的密码
        Object credentials = MD5(principal, userInfoService.getPwd(principal));
        //当前对象的name
        String realmName = this.getName();
        SimpleAuthenticationInfo info = null;
        // 使用盐值加密：防止两个人的密码一样导致加密后的密钥也一致性，所以要加点盐
        ByteSource credentialsSalt = ByteSource.Util.bytes(principal);
        info = new SimpleAuthenticationInfo(principal, credentials, credentialsSalt, realmName);
        return info;
    }

    /***
     * 内测 MD5 加密
     * @param name
     * @param pwd
     * @return
     */
    private Object MD5(String name, String pwd) {
        String hashAlgorithmName = "MD5";
        Object credentials = pwd;
        Object salt = ByteSource.Util.bytes(name);
        int hashIterations = 1024;
        Object result = new SimpleHash(hashAlgorithmName, credentials, salt, hashIterations);
        return result;
    }

    /***
     * 用于授权的方法
     * @param principalCollection
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {

        //1、从PrincipalCollection 中来获取登录用户的信息
        Object primaryPrincipal = principalCollection.getPrimaryPrincipal();
        //2、权限绑定列表
        Set<String> set = new HashSet<String>();
        //3、动态获取权限列表
        List<String> userRoList = userInfoService.getUserRoList((String) primaryPrincipal);
        //4、循环动态绑定
        for (String item : userRoList) {
            set.add(item);
        }
        //5、创建 SimpleAuthorizationInfo ，并设置其 reles 属性
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo(set);
        //6、返回 SimpleAuthenticationInfo 对象。
        return info;
    }
}
