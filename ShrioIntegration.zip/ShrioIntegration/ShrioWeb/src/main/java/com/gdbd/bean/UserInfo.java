package com.gdbd.bean;
import java.util.List;
/**
 * @author asus
 */
public class UserInfo {

    /***
     * 主键ID
     */
    private Integer id;
    /***
     * 用户名
     */
    private String userName;
    /***
     * 用户密码
     */
    private String userPwd;
    /***
     * 角色名称
     */
    private RoleInfo roleInfo;
    /***
     * 权限列表
     */
    //private List<MenuInfo> menuInfoList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }

    public RoleInfo getRoleInfo() {
        return roleInfo;
    }

    public void setRoleInfo(RoleInfo roleInfo) {
        this.roleInfo = roleInfo;
    }

}
