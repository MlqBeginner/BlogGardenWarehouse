package com.gdbd.mapper;

import com.gdbd.bean.MenuInfo;
import com.gdbd.bean.RoleInfo;
import com.gdbd.bean.UserInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * @author asus
 */
@Repository
public interface UserInfoMapper {

    /***
     * 用户登录
     * @param name
     * @param pwd
     * @return
     */
    public UserInfo userInfo(@Param("name") String name, @Param("pwd") String pwd);

    /**
     * 查询所有角色
     * @return
     */
    public List<RoleInfo> roleList();

    /**
     * 获取权限菜单列表
     * @return
     */
    public List<MenuInfo> menuList();

    /***
     * 查询密码
     * @param name 用户名
     * @return
     */
    public String getPwd(@Param("name")String name);

    /***
     * 查询当前用户仅有的权限列表
     * @param name
     * @return
     */
    public List<String> getUserRoList(@Param("name") String name);

    /***
     * 绑定权限
     * @param roleId
     * @param menuId
     * @return
     */
    public int addRo(@Param("roleId") Integer roleId,@Param("menuId")Integer menuId);


}
