package com.gdbd.controller;

import com.gdbd.bean.MenuInfo;
import com.gdbd.bean.RoleInfo;
import com.gdbd.bean.UserInfo;
import com.gdbd.service.UserInfoService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


/**
 * @author asus
 */
@Controller
public class UserContorller {

    @Autowired
    private UserInfoService userInfoService;

    @RequestMapping("/test")
    public void test() {
        UserInfo userInfo = userInfoService.userInfo("MLQ", "123");
        System.out.println(userInfo.getUserName());
        System.out.println(userInfo.getRoleInfo().getRoleName());

        List<RoleInfo> roleInfos = userInfoService.roleList();
        System.out.println("角色：" + roleInfos.size());

        List<MenuInfo> menuInfos = userInfoService.menuList();
        System.out.println("权限列表：" + menuInfos.size());


        String pwd = userInfoService.getPwd("MLQ");
        System.out.println("========" + pwd);

        List<String> userRoList = userInfoService.getUserRoList("MLQ");
        System.out.println("=======xxxxxxxx" + userRoList.size());
    }


    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ModelAndView login(@RequestParam("userName") String userName,
                              @RequestParam("passWord") String passWord) {
        ModelAndView model = new ModelAndView("index");
        //1、角色列表
        List<RoleInfo> roleInfos = userInfoService.roleList();
        //2、权限列表
        List<MenuInfo> menuInfos = userInfoService.menuList();
        //3、绑定
        model.addObject("roleInfos", roleInfos);
        model.addObject("menuInfos", menuInfos);
        /***
         * 是每个请求创建一个Subject;
         * 并保存到ThreadContext的resources（ThreadLocal<Map<Object, Object>>）变量中;
         * 也就是一个http请求一个subject,并绑定到当前线程。
         */
        Subject currentUser = SecurityUtils.getSubject();
        //是否为真,为真就是已授权用户否则就是未授权用户
        if (!currentUser.isAuthenticated()) {
            //01、把用户名和密码封装为 UsernamePasswordToken 对象
            UsernamePasswordToken token = new UsernamePasswordToken(userName, passWord);
            //02、setRememberMe 记住我
            //token.setRememberMe(true);
            try {
                //执行登录.
                currentUser.login(token);
            }
            //所有认证时异常的父类.
            catch (AuthenticationException ae) {
                System.out.println("登陆失败" + ae.getMessage());
            }
        }
        return model;
    }

    @RequestMapping("/addRo")
    public ModelAndView addRo(@RequestParam("roleId") String roleId,
                              @RequestParam("menuId") String menuId) {
        ModelAndView model = new ModelAndView("redirect:/login.jsp");
        String[] split = menuId.split(",");
        int[] menus = new int[split.length];
        for (int i = 0; i < split.length; i++) {
            menus[i] = Integer.parseInt(split[i]);
        }
        try {
            userInfoService.addRo(Integer.valueOf(roleId), menus);
            //登出清除缓存
            Subject currentUser = SecurityUtils.getSubject();
            currentUser.logout();
        } catch (RuntimeException ex) {
            model.setViewName("index");
            model.addObject("error", "权限提交失败");
            ex.printStackTrace();
        }
        return model;
    }

}
