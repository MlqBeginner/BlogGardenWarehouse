package service;


import entity.Book;

/**
 * Created by Happy on 2018-11-22.
 */
public interface IBookService {
    public int addBook(Book book);
}
