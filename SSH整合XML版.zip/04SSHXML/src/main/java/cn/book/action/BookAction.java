package cn.book.action;/**
 * Created by Happy on 2018-11-22.
 */

import cn.book.entity.Book;
import cn.book.service.IBookService;
import com.opensymphony.xwork2.ActionSupport;

/**
 * 作者：微冷的雨
 *
 * @create 2018-11-22
 * 博客地址:www.cnblogs.com/weilengdeyu
 */
public class BookAction extends ActionSupport {


    private Book book;
    IBookService bookService;
    public String addBook(){
        int result = bookService.addBook(book);
        if (result>0){
            return SUCCESS;
        }else{
            return "add";
        }
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public IBookService getBookService() {
        return bookService;
    }

    public void setBookService(IBookService bookService) {
        this.bookService = bookService;
    }
}
