package cn.book.dao.impl;/**
 * Created by Happy on 2018-11-22.
 */

import cn.book.dao.IBookDAO;
import cn.book.entity.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.io.Serializable;

/**
 * 作者：微冷的雨
 *
 * @create 2018-11-22
 * 博客地址:www.cnblogs.com/weilengdeyu
 */
public class BookDAOImpl implements IBookDAO {

    SessionFactory sessionFactory;
    @Override
    public int addBook(Book book) {
        Session session = sessionFactory.getCurrentSession();
        Serializable result = session.save(book);
        return (Integer) result;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
