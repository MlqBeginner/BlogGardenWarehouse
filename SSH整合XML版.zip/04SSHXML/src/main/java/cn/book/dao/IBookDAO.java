package cn.book.dao;/**
 * Created by Happy on 2018-11-22.
 */

import cn.book.entity.Book;

/**
 * 作者：微冷的雨
 *
 * @create 2018-11-22
 * 博客地址:www.cnblogs.com/weilengdeyu
 */
public interface IBookDAO {
    public int addBook(Book book);
}
