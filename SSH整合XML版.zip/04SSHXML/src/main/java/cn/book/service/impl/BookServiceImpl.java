package cn.book.service.impl;/**
 * Created by Happy on 2018-11-22.
 */

import cn.book.dao.IBookDAO;
import cn.book.entity.Book;
import cn.book.service.IBookService;
import org.springframework.transaction.annotation.Transactional;

/**
 * 作者：微冷的雨
 *
 * @create 2018-11-22
 * 博客地址:www.cnblogs.com/weilengdeyu
 */
public class BookServiceImpl implements IBookService {
    IBookDAO bookDAO;
    @Override
    @Transactional
    public int addBook(Book book) {
        return bookDAO.addBook(book);
    }

    public IBookDAO getBookDAO() {
        return bookDAO;
    }

    public void setBookDAO(IBookDAO bookDAO) {
        this.bookDAO = bookDAO;
    }
}
